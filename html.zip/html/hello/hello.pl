#!/usr/bin/perl

# hello.pl -- my first perl script!

print "Content-type: text/html\n\n";

print "Hello, world!\n";

